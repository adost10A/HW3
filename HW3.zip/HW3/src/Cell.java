import java.util.*;
// Spreadsheet Cells can be one of three different kinds:
// - Formulas always start with the = sign.  If the 0th character in
//   contents is a '=', use the method
//     FNode root = FNode.parseFormulaString(contents);
//   to create a formula tree of FNodes for later use.
// - Numbers can be parsed as doubles using the
//   Double.parseDouble(contents) method.
// - Strings are anything else aside from Formulas and Numbers and
//   store only the contents given.
//
// Cells are largely immutable: once the contents of a cell are set,
// they do not change except to reflect movement of upstream dependent
// cells in a formula.  The value of a formula cell may change after
// if values change in its dependent cells. To make changes in a
// spreadsheet, one will typically create a new Cell with different
// contents using the method
//   newCell = Cell.make(contents);
//
// This class may contain nested static subclasses to implement the
// different kinds of cells.
public class Cell {


    // Factory method to create cells with the given contents linked to
    // the given spreadsheet.  The method is static so that one invokes it with:
    //
    //   Cell c = Cell.make("=A21*2");
    //
    // The return value may be a subclass of Cell which is not possible
    // with constructors.  Call trim() on the contents string to remove
    // whitespace at the beginning and end.  If the contents is null or
    // empty, return null.  If contents is not valid, a RuntimeException
    // is generated.
    //
    // If the cell is a formula, it is not possible to evaluate its
    // formula during Cell.make() as other references to other cells
    // cannot be resolved.  The formula can only be reliably evaluated
    // after a call to cell.updateValue(cellMap) is made later.  Until
    // that time the cell should be in the ERROR state with
    // cell.isError() == true and displayString() == "ERROR" and
    // cell.numberValue() == null.
    protected double value;
    protected double evaluted;
    protected FNode root;
    protected String s;
    protected String raw;
    public Cell(double value, String content) {
        this.value = value;
        this.raw = content;
    }

    public Cell(FNode root, String content) {
        this.raw = content;
        this.root = root;
    }

    public Cell(String s) {
        this.raw = s;
        this.s = s;
    }

    public static Cell make(String contents) {
        contents = contents.trim();
        FNode root;
        Double value;
        try {
            value = Double.parseDouble(contents); //return number
            return new Cell(value, contents);
        } catch (NumberFormatException e) {
            if (contents.charAt(0) == '=') {
                root = FNode.parseFormulaString(contents); //return formula
                return new Cell(root, contents);
            } else {
                return new Cell(contents); //return string
            }
        }
    }

    // Return the kind of the cell which is one of "string", "number",
    // or "formula".
    public String kind() {
        if (root != null) {
            return "formula";
        }
        if (s != null) {
            return "string";
        }
        return "number";
    }

    // Returns whether the cell is currently in an error state. Cells
    // with kind() "string" and "number" are never in error.  Formula
    // cells are in error and show ERROR if their formula involves cells
    // which are blank or have kind "string" and therefore cannot be
    // used to calculate the value of the cell.
    public boolean isError() {
        String kind = kind();
        if (kind == "string" || kind == "number") {
            return false;
        }
        if(value!=0.0)
        {
            return false;
        }
        return true;
    }

    // Produce a string to display the contents of the cell.  For kind()
    // "string" and "number", this method returns the original contents
    // of the cell.  For formula cells which are in error, return the
    // string "ERROR".  Formula cells which are not in error return a
    // string of their numeric value with 1 decimal digit of accuracy
    // which is easiest to produce with the String.format() method.
    //
    // Target Complexity: O(1)
    // Avoid repeated formula evaluation by traversing the formula tree
    // only in updateFormulaValue()
    public String displayString() {

        if (s != null) {
            return s;
        }
        if (isError() == true) {
            //If the formula cell isn't in error
            return "ERROR";
        }
        return String.format("%.1f", value);

    }

    // Return the numeric value of this cell.  If the cell is kind
    // "number", this is the double value of its contents.  For kind
    // "formula", it is the evaluated value of the formula.  For kind
    // "string" return null.
    //
    // Target Complexity: O(1)
    // Avoid repeated formula evaluation by traversing the formula tree
    // only in updateFormulaValue()
    public Double numberValue() {
        if (kind() == "number") {
            return value;
        }
        if(kind()=="formula")
        {
            if(!isError())
            {
                return value;
            }
        }
        //ADD WHAT TO DO W/ FORMULA

        return null;

    }

    // Return the raw contents of the cell. For kind() "number" and
    // "string", this is the original contents entered into the cell.
    // For kind() "formula", this is the text of the formula.
    //
    // Target Complexity: O(1)
    public String contents() {

        if(kind()=="formula")
        {
            return raw;
        }
        return raw;
    }

    // Update the value of the cell value. If the cell is not a formula
    // (string and number), do nothing.  Formulas should re-evaluate the
    // stored formula tree to determine a numeric value.  This method
    // may be called when the cell is initially created to give it a
    // numeric value in which case an empty map should be used.
    // Whenever an upstream cell changes value, the housing spreadsheet
    // will call this method to recompute the numeric value to reflect
    // the change.  This method should not raise any exceptions if there
    // are problems evaluating the formula due to other unusable cells.
    // It should set the state of this cell to be in error so that a
    // call to isError() returns true.  If the cell formula is
    // successfully evaluated, isError() should return false.
    //
    // Target Complexity:
    //   O(1) for "number" and "string" cells
    //   O(T) for "formula" nodes where T is the number of nodes in the
    //        formula tree

    public void updateValue(Map<String, Cell> cellMap) {
        if (kind() == "string" || kind() == "number") {
            return;
        }
        try
        {
            value = evalFormulaTree(root,cellMap);
        }
        catch(Exception e)
        {
            return;
        }

    }

        // A simple class to reflect problems evaluating a formula tree.
        public static class EvalFormulaException extends RuntimeException{

            public EvalFormulaException(String msg)
            {
                super(msg);
            }

        }

    // Recursively evaluate the formula tree rooted at the given
    // node. Return the computed value.  Use the given map to retrieve
    // the number value of cells which appear in the formula.  If any
    // cell ID in the formula is unusable (blank, error, string), this
    // method raises an EvalFormulaException.
    //
    // This method is public and static to allow for testing independent
    // of any individual cell but should be used in the
    // updateFormulaValue() method to allow individual cells to compute
    // their formula values.
    //
    // Inspect the FNode and TokenType classes to gain insight into what
    // information is available in FNodes to inspect during the
    // post-order traversal for evaluation.
    //
    // Target Complexity: O(T)
    //   T: the number of nodes in the formula tree

    public static Double evalFormulaTree(FNode node, Map<String, Cell> cellMap) {
        FNode right, left;
        double right_value = 0;
        double left_value = 0;
        right = node.right;
        left = node.left;
        if(right==null&&left==null)
        {
            if(node.type.typeString=="CellID")
            {
                if(!cellMap.containsKey(node.data))
                {
                    throw new EvalFormulaException("Cell can't be found");
                }
                return Double.parseDouble(cellMap.get(node.data).contents());
            }
            return Double.parseDouble(node.data);
        }
        while (true)
        {
            /* Evaluate the left side's right side then left side left*/
            if(right==null)
            {
                break;
            }
            if(right.type.typeString=="CellID")
            {
                if(!cellMap.containsKey(right.data))
                {
                    throw new EvalFormulaException("Right Cell isn't in Cell Map");
                }
                right_value+=Double.parseDouble(cellMap.get(right.data).contents());
            }
            else if (right.type.typeString == "Number") {
                right_value += Double.parseDouble(right.data);
            }
            else
            {
                 right_value+= evalFormulaTree(right,cellMap);
            }
            break;
        }
        while (true)
        {
        if (left==null)
        {
            break;
        }
        if(left.type.typeString=="CellID")
        {
            if(!cellMap.containsKey(left.data))
            {
                throw new EvalFormulaException("Left Cell isnt' in Cell Map");
            }
            left_value+=Double.parseDouble(cellMap.get(left.data).contents());
        }
        else if (left.type.typeString == "Number") {
            left_value += Double.parseDouble(left.data);
        }
        else
        {
            left_value+= evalFormulaTree(left,cellMap);
        }
        break;
    }

        String middle = node.type.typeString;
        if(middle == "CellID")
        {
            if(!cellMap.containsKey(node.data))
            {
                throw new EvalFormulaException("Node doesn't have a reference");
            }
            return cellMap.get(node.data).numberValue();

        }
        if (middle == "+") {
            return left_value + right_value;
        }
        if (middle == "-") {
            return left_value - right_value;
        }
        if (middle == "*") {
            return left_value * right_value;
        }
        if (middle == "/") {
            return left_value / right_value;
        }
        if(middle=="negate")
        {
            return (left_value* -1) + right_value;
        }
        if(middle=="Number")
        {
            return Double.parseDouble(node.data);
        }
        return left_value+right_value;
    }
    // Return a set of upstream cells from this cell. Cells of kind
    // "string" and "number" return an empty set.  Formula cells are
    // dependent on the contents of any cell whose ID appears in the
    // formula and returns all such ids in a set.  For formula cells,
    // this method should call a recursive helper method to traverse the
    // formula tree and accumulate a set of ids in the formula tree.
    //
    // Target Complexity: O(T)
    // Avoid repeated formula evaluation by traversing the formula tree
    // only in updateFormulaValue()
    /* This helper method will store the varables into references for getUpstreamID's() */
    public void traverse(FNode root,Set<String> references)
    {
        if(root.type.typeString=="CellID")
        {
            references.add(root.data);
        }
        if(root.left!=null)
        {
            traverse(root.left,references);
        }
        if(root.right!=null)
        {
            traverse(root.right,references);
        }

    }
    public Set<String> getUpstreamIDs() {
        Set<String> refer = new HashSet<String>();
        traverse(root,refer);
        return refer;
    }
public static Map<String,Cell> cellMap(String... args){
    Map<String,Cell> cellMap = new HashMap<String,Cell>();
    for(int i=0; i<args.length; i+=2){
        String id = args[i];
        Cell cell = Cell.make(args[i+1]);
        cellMap.put(id,cell);
    }
    return cellMap;
}


    public static void main(String[] args) {
        Cell cell = Cell.make("=2 * (20 + CX5)");
        cell.updateValue(cellMap("A1","2.0","CX5","5.22"));
        System.out.println(cell.root.toString());
    }
}