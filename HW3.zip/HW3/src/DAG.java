import org.omg.CORBA.StringHolder;

import java.util.*;


import static java.util.Collections.EMPTY_SET;

// Model a Directed Acyclic Graph (DAG) which allows nodes (vertices)
// to be specified by name as strings and added to the DAG by
// specifiying their upstream dependencies as a set of string IDs.
// Attempting to introduce a cycle causes an exception to be thrown.
public class DAG{
    protected Map<String,Set<String>> upstream,downstream;


    // Construct an empty DAG
    public DAG()
    {
        upstream = new HashMap<String,Set<String>>();
        downstream = new HashMap<String,Set<String>>();
    }

    // Produce a string representaton of the DAG which shows the
    // upstream and downstream links in the graph.  The format should be
    // as follows:
    //
    // Upstream Links:
    //   A1 : [E1, F2, C1]
    //   C1 : [E1, F2]
    //  BB8 : [D1, C1, RU37]
    // RU37 : [E1]
    // Downstream Links:
    //   E1 : [A1, C1, RU37]
    //   F2 : [A1, C1]
    //   D1 : [BB8]
    // RU37 : [BB8]
    //   C1 : [A1, BB8]
    public String toString()
    {
        StringBuilder toString = new StringBuilder();
        toString.append("Upstream Links:\n");
        for(String key: upstream.keySet())
        {
            toString.append(String.format("%4s",key));
            toString.append(" : " + upstream.get(key) + "\n");

        }

        toString.append("Downstream Links:\n");
        for(String key: downstream.keySet())
        {
            toString.append(String.format("%4s",key));
            toString.append(" : " + downstream.get(key) + "\n");

        }
        return toString.toString();
    }

    // Return the upstream links associated with the given ID.  If there
    // are no links associated with ID, return the empty set.
    //
    // TARGET COMPLEXITY: O(1)
    public Set<String> getUpstreamLinks(String id)
    {
        Set<String> empty = EMPTY_SET;
        if(!upstream.containsKey(id))
        {
            return empty;
        }
        return upstream.get(id);
    }

    // Return the downstream links associated with the given ID.  If
    // there are no links associated with ID, return the empty set.
    //
    // TARGET COMPLEXITY: O(1)
    public Set<String> getDownstreamLinks(String id)
    {
        Set<String> empty = EMPTY_SET;
        if(!downstream.containsKey(id))
        {
            return empty;
        }
        return downstream.get(id);
    }

    // Class representing a cycle that is detected on adding to the
    // DAG. Raised in checkForCycles(..) and add(..).
    public static class CycleException extends RuntimeException{

        public CycleException(String msg)
        {
            super(msg);
        }


    }

    // Add a node to the DAG with the provided set of upstream links.
    // Add the new node to the downstream links of each upstream node.
    // If the upstreamIDs argument is either null or empty, remove the
    // node with the given ID.
    //
    // After adding the new node, check whether it has created any
    // cycles through use of the checkForCycles() method.  If a cycle is
    // created, revert the DAG back to its original form so it appears
    // there is no change and raise a CycleException with a message
    // showing the cycle that would have resulted from the addition.
    //
    // TARGET RUNTIME COMPLEXITY: O(N + L)
    // MEMORY OVERHEAD: O(P)
    //   N : number of nodes in the DAG
    //   L : number of upstream links in the DAG
    //   P : longest path in the DAG starting from node id
    public void add(String id, Set<String> upstreamIDs)
    {

        if(upstreamIDs.size()==0)
        {
            if(!upstream.containsKey(id))
            {
                return;
            }
        }

        if(upstream.containsKey(id))
        {

            //Remove "id" from downstream links
            for(String key: upstream.get(id))
            {

                if(downstream.containsKey(key))
                {
                    downstream.get(key).remove(id);
                    if(downstream.get(key).size()==0)
                    {
                        downstream.remove(key);
                    }
                }
            }
            upstream.replace(id,upstreamIDs);
            if(upstream.get(id).size()==0)
            {
                upstream.remove(id);
            }
        }
        else
        {
            upstream.put(id,upstreamIDs);
        }
        for(String ID: upstreamIDs)
        {
            if(!downstream.containsKey(ID))
            {
                Set<String> hash = new HashSet<>();
                hash.add(id);
                downstream.put(ID,hash);
            }
            else
            {
                downstream.get(ID).add(id);
            }
        }
    }

//    // Determine if there is a cycle in the graph represented in the
//    // links map.  List curPath is the current path through the graph,
//    // the last element of which is the current location in the graph.
//    // This method should do a recursive depth-first traversal of the
//    // graph visiting each neighbor of the current element. Each
//    // neighbor should be checked to see if it equals the first element
//    // in curPath in which case there is a cycle.
//    //
//    // This method should return true if a cycle is found and curPath
//    // should be left to contain the cycle that is found.  Return false
//    // if no cycles exist and leave the contents of curPath as they were
//    // originally.
//    //
//    // The method should be used during add(..) which will initialize
//    // curPath to the new node being added and use the upstream links as
//    // the links passed in.
    public static boolean checkForCycles(Map<String, Set<String>> links, List<String> curPath)
    {
        String lastnode = curPath.get(curPath.size()-1);
        Set<String> neighbors = links.get(lastnode);

        if(neighbors.isEmpty()|| neighbors==null)
        {
            return false;
        }
        for(String NID: neighbors)
        {
            curPath.add(NID);
            if(curPath.get(0).equals(NID))
            {
                return true;
            }
            boolean result = checkForCycles(links, curPath);
            if(result)
            {
                return true;
            }
            curPath.remove(curPath.size()-1);
        }
        return false;
    }
//
//    // Remove the given id by eliminating it from the downstream links
//    // of other ids and eliminating its upstream links.  If the ID has
//    // no upstream dependencies, do nothing.
//    //
//    // TARGET COMPLEXITY: O(L_i)
//    //   L_i : number of upstream links node id has

// Removing a node eliminates its upstream links and eliminates it
// from the downstream links of upstream nodes. It does not remove its
// downstream links.

    public void remove(String id)
    {

        if(!upstream.containsKey(id))
        {
            return;
        }
        else
        {
            for(String key: downstream.keySet())
            {
                if(downstream.get(key).contains(id))
                {
                    downstream.get(key).remove(id);
                }
            }
            upstream.remove(id);
        }
        List<String> keys = new ArrayList<String>();
        keys.addAll(downstream.keySet());
        for(String k: keys)
        {
            if(downstream.get(k).size()==0)
            {
                downstream.remove(k);
            }
        }

    }
    public static void main(String[] args)
    {

        DAG dag = new DAG();
        dag.add("A1",DAGDemo.toSet("B1"));
        dag.add("B1",DAGDemo.toSet("C1","D1"));
        System.out.println(dag);
    }

}